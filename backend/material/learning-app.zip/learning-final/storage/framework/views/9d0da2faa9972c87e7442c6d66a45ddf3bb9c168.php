<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.jumbotron', ['title' => 'Manejar mis facturas', 'icon' => 'archive'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pl-5 pr-5">
        <div class="row justify-content-center">
            <table class="table table-hover table-dark">
                <thead>
                    <tr>
                        <th><?php echo e(__("Fecha de la suscripción")); ?></th>
                        <th><?php echo e(__("Coste de la suscripción")); ?></th>
                        <th><?php echo e(__("Cupón")); ?></th>
                        <th><?php echo e(__("Descargar factura")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($invoice->date()->format('d/m/Y')); ?></td>
                            <td><?php echo e($invoice->total()); ?></td>
                            <?php if($invoice->hasDiscount()): ?>
                                <td>
                                    <?php echo e(__("Cupón")); ?>: (<?php echo e($invoice->coupon()); ?> / <?php echo e($invoice->discount()); ?>)
                                </td>
                            <?php else: ?>
                                <td><?php echo e(__("No se ha utilizado ningún cupón")); ?></td>
                            <?php endif; ?>
                            <td>
                                <a class="btn btn-course" href="<?php echo e(route('invoices.download', ['id' => $invoice->id])); ?>">
                                    <?php echo e(__("Descargar")); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4"><?php echo e(__("No hay ninguna factura disponible")); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
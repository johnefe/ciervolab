<form action="<?php echo e(route('subscriptions.process_subscription')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input
        class="form-control"
        name="coupon"
        placeholder="<?php echo e(__("¿Tienes un cupón?")); ?>"
    />
    <input type="hidden" name="type" value="<?php echo e($product['type']); ?>" />
    <hr />
    <stripe-form
        stripe_key="<?php echo e(env('STRIPE_KEY')); ?>"
        name="<?php echo e($product['name']); ?>"
        amount="<?php echo e($product['amount']); ?>"
        description="<?php echo e($product['description']); ?>"
    ></stripe-form>
</form>
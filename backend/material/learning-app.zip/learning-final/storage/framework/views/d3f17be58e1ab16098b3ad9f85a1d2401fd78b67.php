<?php $__env->startComponent('mail::message'); ?>
# <?php echo e(__("Nuevo estudiante en tu curso!")); ?>


<?php echo e(__("El estudiante :student se ha inscrito en tu curso :course, FELICIDADES", ['student' => $student, 'course' => $course->name])); ?>

<img class="img-responsive" src="<?php echo e(url('storage/courses/' . $course->picture)); ?>" alt="<?php echo e($course->name); ?>">

<?php $__env->startComponent('mail::button', ['url' => url('/courses/' . $course->slug), 'color' => 'red']); ?>
    <?php echo e(__("Ir al curso")); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__("Gracias")); ?>,<br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?>
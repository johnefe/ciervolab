<li><a class="nav-link" href="<?php echo e(route('profile.index')); ?>"><?php echo e(__("Mi perfil")); ?></a></li>
<li><a class="nav-link" href="#"><?php echo e(__("Mis suscripciones")); ?></a></li>
<li><a class="nav-link" href="<?php echo e(route('invoices.admin')); ?>"><?php echo e(__("Mis facturas")); ?></a></li>
<li><a class="nav-link" href="<?php echo e(route('courses.subscribed')); ?>"><?php echo e(__("Mis cursos")); ?></a></li>
<li><a class="nav-link" href="<?php echo e(route('teacher.courses')); ?>"><?php echo e(__("Cursos desarrollados por mi")); ?></a></li>
<li><a class="nav-link" href="<?php echo e(route('courses.create')); ?>"><?php echo e(__("Crear curso")); ?></a></li>
<?php echo $__env->make('partials.navigations.logged', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
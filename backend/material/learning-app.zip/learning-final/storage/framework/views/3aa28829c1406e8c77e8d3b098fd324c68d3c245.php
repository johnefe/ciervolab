<div class="align-content-center">
    <div class="col-12 pt-0 mt-4">
        <h2 class="text-muted"><?php echo e(__("Valoraciones")); ?></h2><hr />
    </div>
    <div class="container-fluid">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $course->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-8 offset-2 listing-block">
                    <div class="media">
                        <img
                            class="img-rounded"
                            src="<?php echo e($review->user->pathAttachment()); ?>"
                            alt="<?php echo e($review->user->name); ?>"
                        />
                        <div class="media-body pl-3">
                            <?php if($review->comment): ?>
                                <div class="price"><small><?php echo e($review->comment); ?></small></div>
                            <?php endif; ?>
                            <div class="stats">
                                <?php echo e($review->created_at->format('d/m/Y')); ?>

                                <?php echo $__env->make('partials.courses.rating', ['rating' => $review->rating], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-dark"><i class="fa fa-info-circle"></i> <?php echo e(__("Sin valoraciones todavía")); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="btn-group">
    <?php if((int) $course->status === \App\Course::PUBLISHED): ?>
        <a class="btn btn-course" href="<?php echo e(route('courses.detail', ["slug" => $course->slug])); ?>">
            <i class="fa fa-eye"></i> <?php echo e(__("Detalle")); ?>

        </a>
        <a class="btn btn-warning text-white" href="<?php echo e(route('courses.edit', ["slug" => $course->slug])); ?>">
            <i class="fa fa-pencil"></i> <?php echo e(__("Editar curso")); ?>

        </a>
        <?php echo $__env->make('partials.courses.btn_forms.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif((int) $course->status === \App\Course::PENDING): ?>
        <a class="btn btn-primary text-white" href="#">
            <i class="fa fa-history"></i> <?php echo e(__("Curso pendiente de revisión")); ?>

        </a>
        <a class="btn btn-course" href="<?php echo e(route('courses.detail', ["slug" => $course->slug])); ?>">
            <i class="fa fa-eye"></i> <?php echo e(__("Detalle")); ?>

        </a>
        <a class="btn btn-warning text-white" href="<?php echo e(route('courses.edit', ["slug" => $course->slug])); ?>">
            <i class="fa fa-pencil"></i> <?php echo e(__("Editar curso")); ?>

        </a>
        <?php echo $__env->make('partials.courses.btn_forms.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        <a class="btn btn-danger text-white" href="#">
            <i class="fa fa-pause"></i> <?php echo e(__("Curso rechazado")); ?>

        </a>
        <?php echo $__env->make('partials.courses.btn_forms.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>
<?php $__env->startComponent('mail::message'); ?>

# <?php echo e(__("Nuevo mensaje")); ?>


<?php echo e($text_message); ?>


<?php $__env->startComponent('mail::button', ['url' => url('/')]); ?>
    <?php echo e(__("Ir a :app", ['app' => env('APP_NAME')])); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__("Gracias")); ?>,<br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?>
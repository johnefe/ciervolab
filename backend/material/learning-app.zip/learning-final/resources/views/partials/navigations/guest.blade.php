<li><a class="nav-link" href="{{ route('login') }}">{{ __("Iniciar sesión") }}</a></li>
<li><a class="nav-link" href="{{ route('register') }}">{{ __("Registrarme") }}</a></li>